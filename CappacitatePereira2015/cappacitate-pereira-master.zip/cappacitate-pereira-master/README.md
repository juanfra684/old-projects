# cappacitate-pereira

En este repositorio quedarán alojados los ejercicios de las sesiones de www.cappacitate.com edición 2015.
En la ciudad de Pereira.

#Cappacitate2015 en redes sociales cubrirá el evento para las fechas 10-11 Abril de 2015.